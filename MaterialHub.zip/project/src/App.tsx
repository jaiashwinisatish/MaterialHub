import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Homepage from './pages/Homepage';
import VendorDashboard from './pages/VendorDashboard';
import SupplierDashboard from './pages/SupplierDashboard';
import { MaterialProvider } from './context/MaterialContext';
import { LanguageProvider } from './context/LanguageContext';

function App() {
  return (
    <LanguageProvider>
      <MaterialProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              <Route path="/" element={<Homepage />} />
              <Route path="/vendor" element={<VendorDashboard />} />
              <Route path="/supplier" element={<SupplierDashboard />} />
            </Routes>
          </div>
        </Router>
      </MaterialProvider>
    </LanguageProvider>
  );
}

export default App;