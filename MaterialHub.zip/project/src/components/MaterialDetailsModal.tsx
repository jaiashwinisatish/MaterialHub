import React from 'react';
import { X, Package, User, Calendar, DollarSign, Hash, FileText } from 'lucide-react';
import { Material } from '../context/MaterialContext';
import { useLanguage } from '../context/LanguageContext';

interface MaterialDetailsModalProps {
  material: Material;
  isOpen: boolean;
  onClose: () => void;
}

const MaterialDetailsModal: React.FC<MaterialDetailsModalProps> = ({ material, isOpen, onClose }) => {
  const { t } = useLanguage();

  if (!isOpen) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'low-stock':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'out-of-stock':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const translateStatus = (status: string) => {
    switch (status) {
      case 'available':
        return t('vendor.available');
      case 'low-stock':
        return t('vendor.lowStock');
      case 'out-of-stock':
        return t('vendor.outOfStock');
      default:
        return status;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">{t('modal.materialDetails')}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Material Header */}
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-2">{material.name}</h3>
              <div className="flex items-center space-x-3">
                <span className="text-lg text-blue-600 font-medium">{material.category}</span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(material.status)}`}>
                  {translateStatus(material.status)}
                </span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-green-600">${material.pricePerUnit.toFixed(2)}</div>
              <div className="text-sm text-gray-500">per {material.unit}</div>
            </div>
          </div>

          {/* Description */}
          {material.description && (
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center space-x-2 mb-2">
                <FileText className="h-5 w-5 text-gray-600" />
                <span className="font-medium text-gray-900">{t('supplier.description')}</span>
              </div>
              <p className="text-gray-700 leading-relaxed">{material.description}</p>
            </div>
          )}

          {/* Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Specifications */}
            <div className="bg-blue-50 rounded-xl p-4">
              <h4 className="font-semibold text-blue-900 mb-4 flex items-center space-x-2">
                <Package className="h-5 w-5" />
                <span>{t('modal.specifications')}</span>
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-blue-700">{t('supplier.category')}:</span>
                  <span className="font-medium text-blue-900">{material.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-700">{t('supplier.unit')}:</span>
                  <span className="font-medium text-blue-900">{material.unit}</span>
                </div>
              </div>
            </div>

            {/* Availability */}
            <div className="bg-green-50 rounded-xl p-4">
              <h4 className="font-semibold text-green-900 mb-4 flex items-center space-x-2">
                <Hash className="h-5 w-5" />
                <span>{t('modal.availability')}</span>
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-green-700">{t('supplier.quantity')}:</span>
                  <span className="font-medium text-green-900">{material.quantity} {material.unit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700">{t('supplier.status')}:</span>
                  <span className="font-medium text-green-900">{translateStatus(material.status)}</span>
                </div>
              </div>
            </div>

            {/* Supplier Info */}
            <div className="bg-orange-50 rounded-xl p-4">
              <h4 className="font-semibold text-orange-900 mb-4 flex items-center space-x-2">
                <User className="h-5 w-5" />
                <span>{t('vendor.supplier')}</span>
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-orange-700">Name:</span>
                  <span className="font-medium text-orange-900">{material.supplier}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-orange-700">{t('supplier.phoneNumber')}:</span>
                  <span className="font-medium text-orange-900">{material.phoneNumber}</span>
                </div>
              </div>
            </div>

            {/* Pricing & Updates */}
            <div className="bg-purple-50 rounded-xl p-4">
              <h4 className="font-semibold text-purple-900 mb-4 flex items-center space-x-2">
                <DollarSign className="h-5 w-5" />
                <span>{t('modal.pricing')}</span>
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-purple-700">{t('vendor.price')}:</span>
                  <span className="font-medium text-purple-900">${material.pricePerUnit.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-700">{t('vendor.updated')}:</span>
                  <span className="font-medium text-purple-900">{material.lastUpdated}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-200">
            <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2">
              <User className="h-5 w-5" />
              <span>{t('modal.contactSupplier')}</span>
            </button>
            <button
              onClick={onClose}
              className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-3 rounded-lg font-medium transition-colors"
            >
              {t('modal.close')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MaterialDetailsModal;