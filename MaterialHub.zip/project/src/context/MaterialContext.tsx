import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface Material {
  id: string;
  name: string;
  category: string;
  supplier: string;
  phoneNumber: string;
  quantity: number;
  unit: string;
  pricePerUnit: number;
  lastUpdated: string;
  status: 'available' | 'low-stock' | 'out-of-stock';
  description: string;
}

interface MaterialContextType {
  materials: Material[];
  updateMaterial: (material: Material) => void;
  addMaterial: (material: Omit<Material, 'id' | 'lastUpdated'>) => void;
  deleteMaterial: (id: string) => void;
}

const MaterialContext = createContext<MaterialContextType | undefined>(undefined);

export const useMaterials = () => {
  const context = useContext(MaterialContext);
  if (!context) {
    throw new Error('useMaterials must be used within a MaterialProvider');
  }
  return context;
};

const initialMaterials: Material[] = [
  {
    id: '1',
    name: 'Organic Tomatoes',
    category: 'Vegetables',
    supplier: 'Green Valley Farms',
    phoneNumber: '+1-555-0123',
    quantity: 150,
    unit: 'kg',
    pricePerUnit: 5.50,
    lastUpdated: '2025-01-08',
    status: 'available',
    description: 'Fresh organic tomatoes, perfect for restaurants and cafes'
  },
  {
    id: '2',
    name: 'Free-Range Eggs',
    category: 'Dairy & Eggs',
    supplier: 'Sunrise Poultry',
    phoneNumber: '+1-555-0456',
    quantity: 25,
    unit: 'dozen',
    pricePerUnit: 8.00,
    lastUpdated: '2025-01-08',
    status: 'low-stock',
    description: 'Premium free-range eggs from pasture-raised hens'
  },
  {
    id: '3',
    name: 'Artisan Bread Flour',
    category: 'Grains',
    supplier: 'Miller\'s Best',
    phoneNumber: '+1-555-0789',
    quantity: 200,
    unit: 'kg',
    pricePerUnit: 3.25,
    lastUpdated: '2025-01-07',
    status: 'available',
    description: 'High-quality flour perfect for artisan bread making'
  },
  {
    id: '4',
    name: 'Fresh Salmon',
    category: 'Seafood',
    supplier: 'Ocean Fresh Co.',
    phoneNumber: '+1-555-0321',
    quantity: 0,
    unit: 'kg',
    pricePerUnit: 18.50,
    lastUpdated: '2025-01-06',
    status: 'out-of-stock',
    description: 'Premium Atlantic salmon, sustainably sourced'
  },
  {
    id: '5',
    name: 'Organic Olive Oil',
    category: 'Oils & Condiments',
    supplier: 'Mediterranean Imports',
    phoneNumber: '+1-555-0654',
    quantity: 80,
    unit: 'liters',
    pricePerUnit: 12.00,
    lastUpdated: '2025-01-08',
    status: 'available',
    description: 'Extra virgin olive oil from certified organic groves'
  }
];

export const MaterialProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [materials, setMaterials] = useState<Material[]>(initialMaterials);

  const updateMaterial = (updatedMaterial: Material) => {
    setMaterials(prev => 
      prev.map(material => 
        material.id === updatedMaterial.id 
          ? { ...updatedMaterial, lastUpdated: new Date().toISOString().split('T')[0] }
          : material
      )
    );
  };

  const addMaterial = (newMaterialData: Omit<Material, 'id' | 'lastUpdated'>) => {
    const newMaterial: Material = {
      ...newMaterialData,
      id: Date.now().toString(),
      lastUpdated: new Date().toISOString().split('T')[0]
    };
    setMaterials(prev => [...prev, newMaterial]);
  };

  const deleteMaterial = (id: string) => {
    setMaterials(prev => prev.filter(material => material.id !== id));
  };

  return (
    <MaterialContext.Provider value={{ materials, updateMaterial, addMaterial, deleteMaterial }}>
      {children}
    </MaterialContext.Provider>
  );
};