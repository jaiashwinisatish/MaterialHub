import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'es' | 'hi' | 'ta' | 'te';

interface Translations {
  [key: string]: {
    [key in Language]: string;
  };
}

const translations: Translations = {
  // Navigation
  'nav.backToHome': {
    en: 'Back to Home',
    es: 'Volver al Inicio',
    hi: 'होम पर वापस जाएं',
    ta: 'முகப்புக்கு திரும்பு',
    te: 'హోమ్‌కు తిరిగి వెళ్లు'
  },
  'nav.vendorDashboard': {
    en: 'Vendor Dashboard',
    es: 'Panel de Vendedor',
    hi: 'विक्रेता डैशबोर्ड',
    ta: 'விற்பனையாளர் டாஷ்போர்டு',
    te: 'విక్రేత డాష్‌బోర్డ్'
  },
  'nav.supplierDashboard': {
    en: 'Supplier Dashboard',
    es: 'Panel de Proveedor',
    hi: 'आपूर्तिकर्ता डैशबोर्ड',
    ta: 'சப்ளையர் டாஷ்போர்டு',
    te: 'సప్లైయర్ డాష్‌బోర్డ్'
  },
  
  // Homepage
  'home.title': {
    en: 'MaterialHub',
    es: 'MaterialHub',
    hi: 'मैटेरियलहब',
    ta: 'மெட்டீரியல்ஹப்',
    te: 'మెటీరియల్‌హబ్'
  },
  'home.subtitle': {
    en: 'Connecting Suppliers & Vendors',
    es: 'Conectando Proveedores y Vendedores',
    hi: 'आपूर्तिकर्ताओं और विक्रेताओं को जोड़ना',
    ta: 'சப்ளையர்கள் மற்றும் விற்பனையாளர்களை இணைக்கிறது',
    te: 'సప్లైయర్లు మరియు విక్రేతలను కనెక్ట్ చేస్తోంది'
  },
  'home.heroTitle': {
    en: 'Streamline Your Material Management',
    es: 'Optimiza tu Gestión de Materiales',
    hi: 'अपने सामग्री प्रबंधन को सुव्यवस्थित करें',
    ta: 'உங்கள் பொருள் மேலாண்மையை सुव्यवस्थित करें',
    te: 'మీ మెటీరియల్ మేనేజ్‌మెంట్‌ను క్రమబద్ధీకరించండి'
  },
  'home.heroDescription': {
    en: 'Connect suppliers and vendors through our comprehensive platform. Track inventory, manage orders, and optimize your supply chain with real-time data.',
    es: 'Conecta proveedores y vendedores a través de nuestra plataforma integral. Rastrea inventario, gestiona pedidos y optimiza tu cadena de suministro con datos en tiempo real.',
    hi: 'हमारे व्यापक प्लेटफॉर्म के माध्यम से आपूर्तिकर्ताओं और विक्रेताओं को जोड़ें। इन्वेंटरी ट्रैक करें, ऑर्डर प्रबंधित करें, और रीयल-टाइम डेटा के साथ अपनी आपूर्ति श्रृंखला को अनुकूलित करें।',
    ta: 'எங்கள் விரிவான தளத்தின் மூலம் சப்ளையர்கள் மற்றும் விற்பனையாளர்களை இணைக்கவும். இன்வென்டரியை கண்காணிக்கவும், ஆர்டர்களை நிர்வகிக்கவும், மற்றும் நிகழ்நேர தரவுகளுடன் உங்கள் விநியோக சங்கிலியை மேம்படுத்தவும்।',
    te: 'మా సమగ్ర ప్లాట్‌ఫారమ్ ద్వారా సప్లైయర్లు మరియు విక్రేతలను కనెక్ట్ చేయండి. ఇన్వెంటరీని ట్రాక్ చేయండి, ఆర్డర్లను నిర్వహించండి, మరియు రియల్-టైమ్ డేటాతో మీ సప్లై చైన్‌ను ఆప్టిమైజ్ చేయండి।'
  },
  'home.vendorButton': {
    en: 'Vendor Dashboard',
    es: 'Panel de Vendedor',
    hi: 'विक्रेता डैशबोर्ड',
    ta: 'விற்பனையாளர் டாஷ்போர்டு',
    te: 'విక్రేత డాష్‌బోర్డ్'
  },
  'home.supplierButton': {
    en: 'Supplier Dashboard',
    es: 'Panel de Proveedor',
    hi: 'आपूर्तिकर्ता डैशबोर्ड',
    ta: 'சப்ளையர் டாஷ்போர்டு',
    te: 'సప్లైయర్ డాష్‌బోర్డ్'
  },
  'home.feature1Title': {
    en: 'Real-Time Tracking',
    es: 'Seguimiento en Tiempo Real',
    hi: 'रीयल-टाइम ट्रैकिंग',
    ta: 'நிகழ்நேர கண்காணிப்பு',
    te: 'రియల్-టైమ్ ట్రాకింగ్'
  },
  'home.feature1Desc': {
    en: 'Monitor inventory levels, prices, and availability in real-time across all your suppliers.',
    es: 'Monitorea niveles de inventario, precios y disponibilidad en tiempo real en todos tus proveedores.',
    hi: 'अपने सभी आपूर्तिकर्ताओं में इन्वेंटरी स्तर, कीमतों और उपलब्धता की रीयल-टाइम निगरानी करें।',
    ta: 'உங்கள் அனைத்து சப்ளையர்களிலும் இன்வென்டரி நிலைகள், விலைகள் மற்றும் கிடைக்கும் தன்மையை நிகழ்நேரத்தில் கண்காணிக்கவும்।',
    te: 'మీ అన్ని సప్లైయర్లలో ఇన్వెంటరీ స్థాయిలు, ధరలు మరియు లభ్యతను రియల్-టైమ్‌లో పర్యవేక్షించండి।'
  },
  'home.feature2Title': {
    en: 'Vendor Management',
    es: 'Gestión de Vendedores',
    hi: 'विक्रेता प्रबंधन',
    ta: 'விற்பனையாளர் மேலாண்மை',
    te: 'విక్రేత నిర్వహణ'
  },
  'home.feature2Desc': {
    en: 'Advanced filtering and search capabilities to find exactly what you need, when you need it.',
    es: 'Capacidades avanzadas de filtrado y búsqueda para encontrar exactamente lo que necesitas, cuando lo necesitas.',
    hi: 'उन्नत फ़िल्टरिंग और खोज क्षमताएं जो आपको वही मिलने में मदद करती हैं जिसकी आपको जरूरत है, जब आपको जरूरत है।',
    ta: 'உங்களுக்கு தேவையானதை, தேவையான நேரத்தில் கண்டுபிடிக்க மேம்பட்ட வடிகட்டல் மற்றும் தேடல் திறன்கள்।',
    te: 'మీకు అవసరమైనది, మీకు అవసరమైనప్పుడు కనుగొనడానికి అధునాతన ఫిల్టరింగ్ మరియు శోధన సామర్థ్యాలు।'
  },
  'home.feature3Title': {
    en: 'Easy Updates',
    es: 'Actualizaciones Fáciles',
    hi: 'आसान अपडेट',
    ta: 'எளிய புதுப்பிப்புகள்',
    te: 'సులభ అప్‌డేట్‌లు'
  },
  'home.feature3Desc': {
    en: 'Suppliers can quickly update material information, prices, and availability with our intuitive forms.',
    es: 'Los proveedores pueden actualizar rápidamente información de materiales, precios y disponibilidad con nuestros formularios intuitivos.',
    hi: 'आपूर्तिकर्ता हमारे सहज रूपों के साथ सामग्री की जानकारी, कीमतों और उपलब्धता को जल्दी अपडेट कर सकते हैं।',
    ta: 'சப்ளையர்கள் எங்கள் உள்ளுணர்வு படிவங்களுடன் பொருள் தகவல், விலைகள் மற்றும் கிடைக்கும் தன்மையை விரைவாக புதுப்பிக்க முடியும்।',
    te: 'సప్లైయర్లు మా సహజమైన ఫారమ్‌లతో మెటీరియల్ సమాచారం, ధరలు మరియు లభ్యతను త్వరగా అప్‌డేట్ చేయవచ్చు।'
  },
  'home.stats.materials': {
    en: 'Active Materials',
    es: 'Materiales Activos',
    hi: 'सक्रिय सामग्री',
    ta: 'செயலில் உள்ள பொருட்கள்',
    te: 'క్రియాశీల మెటీరియల్స్'
  },
  'home.stats.suppliers': {
    en: 'Trusted Suppliers',
    es: 'Proveedores Confiables',
    hi: 'विश्वसनीय आपूर्तिकर्ता',
    ta: 'நம்பகமான சப்ளையர்கள்',
    te: 'విశ్వసనీయ సప్లైయర్లు'
  },
  'home.stats.vendors': {
    en: 'Vendor Partners',
    es: 'Socios Vendedores',
    hi: 'विक्रेता भागीदार',
    ta: 'விற்பனையாளர் கூட்டாளர்கள்',
    te: 'విక్రేత భాగస్వాములు'
  },
  'home.stats.uptime': {
    en: 'Uptime',
    es: 'Tiempo Activo',
    hi: 'अपटाइम',
    ta: 'செயல்பாட்டு நேரம்',
    te: 'అప్‌టైమ్'
  },

  // Vendor Dashboard
  'vendor.materialsAvailable': {
    en: 'Materials Available',
    es: 'Materiales Disponibles',
    hi: 'उपलब्ध सामग्री',
    ta: 'கிடைக்கும் பொருட்கள்',
    te: 'అందుబాటులో ఉన్న మెటీరియల్స్'
  },
  'vendor.searchPlaceholder': {
    en: 'Search materials or suppliers...',
    es: 'Buscar materiales o proveedores...',
    hi: 'सामग्री या आपूर्तिकर्ता खोजें...',
    ta: 'பொருட்கள் அல்லது சப்ளையர்களை தேடுங்கள்...',
    te: 'మెటీరియల్స్ లేదా సప్లైయర్లను వెతకండి...'
  },
  'vendor.allCategories': {
    en: 'All Categories',
    es: 'Todas las Categorías',
    hi: 'सभी श्रेणियां',
    ta: 'அனைத்து வகைகள்',
    te: 'అన్ని వర్గాలు'
  },
  'vendor.allStatus': {
    en: 'All Status',
    es: 'Todos los Estados',
    hi: 'सभी स्थितियां',
    ta: 'அனைத்து நிலைகள்',
    te: 'అన్ని స్థితులు'
  },
  'vendor.available': {
    en: 'Available',
    es: 'Disponible',
    hi: 'उपलब्ध',
    ta: 'கிடைக்கும்',
    te: 'అందుబాటులో'
  },
  'vendor.lowStock': {
    en: 'Low Stock',
    es: 'Stock Bajo',
    hi: 'कम स्टॉक',
    ta: 'குறைந்த स्टாக்',
    te: 'తక్కువ స్టాక్'
  },
  'vendor.outOfStock': {
    en: 'Out of Stock',
    es: 'Sin Stock',
    hi: 'स्टॉक समाप्त',
    ta: 'स्टाक் இல்லை',
    te: 'స్టాక్ లేదు'
  },
  'vendor.sortByName': {
    en: 'Sort by Name',
    es: 'Ordenar por Nombre',
    hi: 'नाम के अनुसार क्रमबद्ध करें',
    ta: 'பெயர் அடிப்படையில் வரிசைப்படுத்து',
    te: 'పేరు ఆధారంగా క్రమబద్ధీకరించు'
  },
  'vendor.sortByPrice': {
    en: 'Sort by Price',
    es: 'Ordenar por Precio',
    hi: 'कीमत के अनुसार क्रमबद्ध करें',
    ta: 'விலை அடிப்படையில் வரிசைப்படுத்து',
    te: 'ధర ఆధారంగా క్రమబద్ధీకరించు'
  },
  'vendor.sortByQuantity': {
    en: 'Sort by Quantity',
    es: 'Ordenar por Cantidad',
    hi: 'मात्रा के अनुसार क्रमबद्ध करें',
    ta: 'அளவு அடிப்படையில் வரிசைப்படுத்து',
    te: 'పరిమాణం ఆధారంగా క్రమబద్ధీకరించు'
  },
  'vendor.sortByUpdated': {
    en: 'Sort by Last Updated',
    es: 'Ordenar por Última Actualización',
    hi: 'अंतिम अपडेट के अनुसार क्रमबद्ध करें',
    ta: 'கடைசி புதுப்பிப்பு அடிப்படையில் வரிசைப்படுத்து',
    te: 'చివరి అప్‌డేట్ ఆధారంగా క్రమబద్ధీకరించు'
  },
  'vendor.supplier': {
    en: 'Supplier',
    es: 'Proveedor',
    hi: 'आपूर्तिकर्ता',
    ta: 'சப்ளையர்',
    te: 'సప్లైయర్'
  },
  'vendor.price': {
    en: 'Price',
    es: 'Precio',
    hi: 'कीमत',
    ta: 'விலை',
    te: 'ధర'
  },
  'vendor.available': {
    en: 'Available',
    es: 'Disponible'
  },
  'vendor.updated': {
    en: 'Updated',
    es: 'Actualizado',
    hi: 'अपडेट किया गया',
    ta: 'புதுப்பிக்கப்பட்டது',
    te: 'అప్‌డేట్ చేయబడింది'
  },
  'vendor.viewDetails': {
    en: 'View Details',
    es: 'Ver Detalles',
    hi: 'विवरण देखें',
    ta: 'விவரங்களைப் பார்க்கவும்',
    te: 'వివరాలను చూడండి'
  },
  'vendor.noMaterials': {
    en: 'No materials found',
    es: 'No se encontraron materiales',
    hi: 'कोई सामग्री नहीं मिली',
    ta: 'பொருட்கள் எதுவும் கிடைக்கவில்லை',
    te: 'మెటీరియల్స్ కనుగొనబడలేదు'
  },
  'vendor.noMaterialsDesc': {
    en: 'Try adjusting your search or filter criteria.',
    es: 'Intenta ajustar tus criterios de búsqueda o filtro.',
    hi: 'अपने खोज या फ़िल्टर मानदंडों को समायोजित करने का प्रयास करें।',
    ta: 'உங்கள் தேடல் அல்லது வடிகட்டி அளவுகோல்களை சரிசெய்ய முயற்சிக்கவும்।',
    te: 'మీ శోధన లేదా ఫిల్టర్ ప్రమాణాలను సర్దుబాటు చేయడానికి ప్రయత్నించండి।'
  },

  // Supplier Dashboard
  'supplier.addMaterial': {
    en: 'Add Material',
    es: 'Agregar Material',
    hi: 'सामग्री जोड़ें',
    ta: 'பொருள் சேர்க்கவும்',
    te: 'మెటీరియల్ జోడించండి'
  },
  'supplier.editMaterial': {
    en: 'Edit Material',
    es: 'Editar Material',
    hi: 'सामग्री संपादित करें',
    ta: 'பொருளைத் திருத்தவும்',
    te: 'మెటీరియల్‌ను సవరించండి'
  },
  'supplier.addNewMaterial': {
    en: 'Add New Material',
    es: 'Agregar Nuevo Material',
    hi: 'नई सामग्री जोड़ें',
    ta: 'புதிய பொருள் சேர்க்கவும்',
    te: 'కొత్త మెటీరియల్ జోడించండి'
  },
  'supplier.materialName': {
    en: 'Material Name',
    es: 'Nombre del Material',
    hi: 'सामग्री का नाम',
    ta: 'பொருளின் பெயர்',
    te: 'మెటీరియల్ పేరు'
  },
  'supplier.category': {
    en: 'Category',
    es: 'Categoría',
    hi: 'श्रेणी',
    ta: 'வகை',
    te: 'వర్గం'
  },
  'supplier.supplierName': {
    en: 'Supplier Name',
    es: 'Nombre del Proveedor',
    hi: 'आपूर्तिकर्ता का नाम',
    ta: 'சப்ளையர் பெயர்',
    te: 'సప్లైయర్ పేరు'
  },
  'supplier.phoneNumber': {
    en: 'Phone Number',
    es: 'Número de Teléfono',
    hi: 'फोन नंबर',
    ta: 'தொலைபேசி எண்',
    te: 'ఫోన్ నంబర్'
  },
  'supplier.status': {
    en: 'Status',
    es: 'Estado',
    hi: 'स्थिति',
    ta: 'நிலை',
    te: 'స్థితి'
  },
  'supplier.quantity': {
    en: 'Quantity',
    es: 'Cantidad',
    hi: 'मात्रा',
    ta: 'அளவு',
    te: 'పరిమాణం'
  },
  'supplier.unit': {
    en: 'Unit',
    es: 'Unidad',
    hi: 'इकाई',
    ta: 'அலகு',
    te: 'యూనిట్'
  },
  'supplier.pricePerUnit': {
    en: 'Price per Unit ($)',
    es: 'Precio por Unidad ($)',
    hi: 'प्रति इकाई मूल्य ($)',
    ta: 'ஒரு அலகுக்கான விலை ($)',
    te: 'యూనిట్‌కు ధర ($)'
  },
  'supplier.description': {
    en: 'Description',
    es: 'Descripción',
    hi: 'विवरण',
    ta: 'விளக்கம்',
    te: 'వివరణ'
  },
  'supplier.cancel': {
    en: 'Cancel',
    es: 'Cancelar',
    hi: 'रद्द करें',
    ta: 'ரத்து செய்',
    te: 'రద్దు చేయండి'
  },
  'supplier.update': {
    en: 'Update',
    es: 'Actualizar',
    hi: 'अपडेट करें',
    ta: 'புதுப்பிக்கவும்',
    te: 'అప్‌డేట్ చేయండి'
  },
  'supplier.add': {
    en: 'Add',
    es: 'Agregar',
    hi: 'जोड़ें',
    ta: 'சேர்க்கவும்',
    te: 'జోడించండి'
  },
  'supplier.yourMaterials': {
    en: 'Your Materials',
    es: 'Tus Materiales',
    hi: 'आपकी सामग्री',
    ta: 'உங்கள் பொருட்கள்',
    te: 'మీ మెటీరియల్స్'
  },
  'supplier.noMaterialsYet': {
    en: 'No materials yet',
    es: 'Aún no hay materiales',
    hi: 'अभी तक कोई सामग्री नहीं',
    ta: 'இன்னும் பொருட்கள் இல்லை',
    te: 'ఇంకా మెటీరియల్స్ లేవు'
  },
  'supplier.addFirstMaterial': {
    en: 'Add your first material to get started.',
    es: 'Agrega tu primer material para comenzar.',
    hi: 'शुरुआत करने के लिए अपनी पहली सामग्री जोड़ें।',
    ta: 'தொடங்க உங்கள் முதல் பொருளைச் சேர்க்கவும்।',
    te: 'ప్రారంభించడానికి మీ మొదటి మెటీరియల్‌ను జోడించండి।'
  },
  'supplier.material': {
    en: 'Material',
    es: 'Material',
    hi: 'सामग्री',
    ta: 'பொருள்',
    te: 'మెటీరియల్'
  },
  'supplier.lastUpdated': {
    en: 'Last Updated',
    es: 'Última Actualización',
    hi: 'अंतिम अपडेट',
    ta: 'கடைசி புதுப்பிப்பு',
    te: 'చివరి అప్‌డేట్'
  },
  'supplier.actions': {
    en: 'Actions',
    es: 'Acciones',
    hi: 'क्रियाएं',
    ta: 'செயல்கள்',
    te: 'చర్యలు'
  },
  'supplier.deleteConfirm': {
    en: 'Are you sure you want to delete this material?',
    es: '¿Estás seguro de que quieres eliminar este material?',
    hi: 'क्या आप वाकई इस सामग्री को हटाना चाहते हैं?',
    ta: 'இந்த பொருளை நீக்க விரும்புகிறீர்களா?',
    te: 'మీరు ఖచ్చితంగా ఈ మెటీరియల్‌ను తొలగించాలనుకుంటున్నారా?'
  },

  // Material Details Modal
  'modal.materialDetails': {
    en: 'Material Details',
    es: 'Detalles del Material',
    hi: 'सामग्री विवरण',
    ta: 'பொருள் விவரங்கள்',
    te: 'మెటీరియల్ వివరాలు'
  },
  'modal.close': {
    en: 'Close',
    es: 'Cerrar',
    hi: 'बंद करें',
    ta: 'மூடு',
    te: 'మూసివేయండి'
  },
  'modal.contactSupplier': {
    en: 'Contact Supplier',
    es: 'Contactar Proveedor',
    hi: 'आपूर्तिकर्ता से संपर्क करें',
    ta: 'சப்ளையரைத் தொடர்பு கொள்ளவும்',
    te: 'సప్లైయర్‌ను సంప్రదించండి'
  },
  'modal.specifications': {
    en: 'Specifications',
    es: 'Especificaciones',
    hi: 'विशिष्टताएं',
    ta: 'விவரக்குறிப்புகள்',
    te: 'వివరణలు'
  },
  'modal.availability': {
    en: 'Availability',
    es: 'Disponibilidad',
    hi: 'उपलब्धता',
    ta: 'கிடைக்கும் தன்மை',
    te: 'లభ్యత'
  },
  'modal.pricing': {
    en: 'Pricing',
    es: 'Precios',
    hi: 'मूल्य निर्धारण',
    ta: 'விலை நிர்ணயம்',
    te: 'ధర నిర్ణయం'
  },

  // Categories
  'category.vegetables': {
    en: 'Vegetables',
    es: 'Vegetales',
    hi: 'सब्जियां',
    ta: 'காய்கறிகள்',
    te: 'కూరగాయలు'
  },
  'category.dairy': {
    en: 'Dairy & Eggs',
    es: 'Lácteos y Huevos',
    hi: 'डेयरी और अंडे',
    ta: 'பால் மற்றும் முட்டைகள்',
    te: 'పాల ఉత్పత్తులు మరియు గుడ్లు'
  },
  'category.grains': {
    en: 'Grains',
    es: 'Granos',
    hi: 'अनाज',
    ta: 'தானியங்கள்',
    te: 'ధాన్యాలు'
  },
  'category.seafood': {
    en: 'Seafood',
    es: 'Mariscos',
    hi: 'समुद्री भोजन',
    ta: 'கடல் உணவு',
    te: 'సముద్రపు ఆహారం'
  },
  'category.oils': {
    en: 'Oils & Condiments',
    es: 'Aceites y Condimentos',
    hi: 'तेल और मसाले',
    ta: 'எண்ணெய்கள் மற்றும் சுவையூட்டிகள்',
    te: 'నూనెలు మరియు మసాలాలు'
  },
  'category.meat': {
    en: 'Meat',
    es: 'Carne',
    hi: 'मांस',
    ta: 'இறைச்சி',
    te: 'మాంసం'
  },
  'category.spices': {
    en: 'Spices',
    es: 'Especias',
    hi: 'मसाले',
    ta: 'மசாலாப் பொருட்கள்',
    te: 'మసాలా దినుసులు'
  },

  // Common
  'common.selectCategory': {
    en: 'Select category',
    es: 'Seleccionar categoría',
    hi: 'श्रेणी चुनें',
    ta: 'வகையைத் தேர்ந்தெடுக்கவும்',
    te: 'వర్గాన్ని ఎంచుకోండి'
  },
  'common.selectUnit': {
    en: 'Select unit',
    es: 'Seleccionar unidad',
    hi: 'इकाई चुनें',
    ta: 'அலகைத் தேர்ந்தெடுக்கவும்',
    te: 'యూనిట్‌ను ఎంచుకోండి'
  },
  'common.enterMaterialName': {
    en: 'Enter material name',
    es: 'Ingresa el nombre del material',
    hi: 'सामग्री का नाम दर्ज करें',
    ta: 'பொருளின் பெயரை உள்ளிடவும்',
    te: 'మెటీరియల్ పేరును నమోదు చేయండి'
  },
  'common.enterSupplierName': {
    en: 'Enter supplier name',
    es: 'Ingresa el nombre del proveedor',
    hi: 'आपूर्तिकर्ता का नाम दर्ज करें',
    ta: 'சப்ளையர் பெயரை உள்ளிடவும்',
    te: 'సప్లైయర్ పేరును నమోదు చేయండి'
  },
  'common.enterPhoneNumber': {
    en: 'Enter phone number',
    es: 'Ingresa el número de teléfono',
    hi: 'फोन नंबर दर्ज करें',
    ta: 'தொலைபேசி எண்ணை உள்ளிடவும்',
    te: 'ఫోన్ నంబర్‌ను నమోదు చేయండి'
  },
  'common.enterDescription': {
    en: 'Enter material description (optional)',
    es: 'Ingresa la descripción del material (opcional)',
    hi: 'सामग्री विवरण दर्ज करें (वैकल्पिक)',
    ta: 'பொருள் விளக்கத்தை உள்ளிடவும் (விருப்பம்)',
    te: 'మెటీరియల్ వివరణను నమోదు చేయండి (ఐచ్ఛికం)'
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};