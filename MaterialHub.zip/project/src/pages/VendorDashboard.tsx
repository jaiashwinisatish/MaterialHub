import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Package, ArrowLeft, Eye, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { useMaterials, Material } from '../context/MaterialContext';
import { useLanguage } from '../context/LanguageContext';
import LanguageSwitcher from '../components/LanguageSwitcher';
import MaterialDetailsModal from '../components/MaterialDetailsModal';

const VendorDashboard: React.FC = () => {
  const { materials } = useMaterials();
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleViewDetails = (material: Material) => {
    setSelectedMaterial(material);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedMaterial(null);
  };

  // Get unique categories
  const categories = ['all', ...Array.from(new Set(materials.map(m => m.category)))];

  // Filter and sort materials
  const filteredMaterials = materials
    .filter(material => {
      const matchesSearch = material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           material.supplier.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || material.category === selectedCategory;
      const matchesStatus = selectedStatus === 'all' || material.status === selectedStatus;
      return matchesSearch && matchesCategory && matchesStatus;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'price':
          return a.pricePerUnit - b.pricePerUnit;
        case 'quantity':
          return b.quantity - a.quantity;
        case 'updated':
          return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
        default:
          return 0;
      }
    });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'low-stock':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'out-of-stock':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-800';
      case 'low-stock':
        return 'bg-yellow-100 text-yellow-800';
      case 'out-of-stock':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const translateStatus = (status: string) => {
    switch (status) {
      case 'available':
        return t('vendor.available');
      case 'low-stock':
        return t('vendor.lowStock');
      case 'out-of-stock':
        return t('vendor.outOfStock');
      default:
        return status;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link
                to="/"
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
                <span>{t('nav.backToHome')}</span>
              </Link>
              <div className="h-6 w-px bg-gray-300"></div>
              <div className="flex items-center space-x-3">
                <Package className="h-6 w-6 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-900">{t('nav.vendorDashboard')}</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 px-4 py-2 rounded-lg">
                <span className="text-blue-800 font-medium">{filteredMaterials.length} {t('vendor.materialsAvailable')}</span>
              </div>
              <LanguageSwitcher />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder={t('vendor.searchPlaceholder')}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Category Filter */}
            <div className="min-w-48">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? t('vendor.allCategories') : category}
                  </option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div className="min-w-48">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">{t('vendor.allStatus')}</option>
                <option value="available">{t('vendor.available')}</option>
                <option value="low-stock">{t('vendor.lowStock')}</option>
                <option value="out-of-stock">{t('vendor.outOfStock')}</option>
              </select>
            </div>

            {/* Sort */}
            <div className="min-w-48">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="name">{t('vendor.sortByName')}</option>
                <option value="price">{t('vendor.sortByPrice')}</option>
                <option value="quantity">{t('vendor.sortByQuantity')}</option>
                <option value="updated">{t('vendor.sortByUpdated')}</option>
              </select>
            </div>
          </div>
        </div>

        {/* Materials Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredMaterials.map((material) => (
            <div key={material.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">{material.name}</h3>
                    <p className="text-sm text-blue-600 font-medium">{material.category}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(material.status)}
                  </div>
                </div>

                <div className="space-y-3 mb-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">{t('vendor.supplier')}:</span>
                    <span className="font-medium">{material.supplier}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">{t('vendor.price')}:</span>
                    <span className="font-bold text-lg">${material.pricePerUnit.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">{t('vendor.available')}:</span>
                    <span className="font-medium">{material.quantity} {material.unit}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">{t('vendor.updated')}:</span>
                    <span className="text-sm">{material.lastUpdated}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(material.status)}`}>
                    {translateStatus(material.status)}
                  </span>
                  <button 
                    onClick={() => handleViewDetails(material)}
                    className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium transition-colors"
                  >
                    <Eye className="h-4 w-4" />
                    <span>{t('vendor.viewDetails')}</span>
                  </button>
                </div>

                {material.description && (
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <p className="text-sm text-gray-600">{material.description}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {filteredMaterials.length === 0 && (
          <div className="text-center py-12">
            <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">{t('vendor.noMaterials')}</h3>
            <p className="text-gray-600">{t('vendor.noMaterialsDesc')}</p>
          </div>
        )}
      </main>

      {/* Material Details Modal */}
      {selectedMaterial && (
        <MaterialDetailsModal
          material={selectedMaterial}
          isOpen={isModalOpen}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
};

export default VendorDashboard;